/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package fashion.shop;

/**
 *
 * @author Sinesh Gimshan
 */
interface OrderList {

    public Orders search(String id);

    public boolean add(Orders order);

    public Orders[] toArray();

    public boolean remove(int index);
    
    public boolean remove(Orders order);
    
    public int indexOf(Orders order);

    public boolean set(Orders order);
    
    public int size();
    
    public Orders get(int index);
    
    public boolean isValidIndex(int index);
    
    public boolean add(int index, Orders order);
    
    public String generateId();
    
    public boolean isValidOrderId(String id);
    
    public void amountSorting(String[] sizes,int[]Quantity,double[] amount);
    
    public void quantitySorting(String[] sizes,int[] Quantity,double[] amount);
    
    public boolean isValidContactNum(String number);
    
    public int FindIndex(String[] uniqueContacts, String currentContact);
    
    public int[] extendArray1(int[] array);
    
    public double[] extendArray2(double[] array);
     
    public String[] extendArray(String[] array);
}