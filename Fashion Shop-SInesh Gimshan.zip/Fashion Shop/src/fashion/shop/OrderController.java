/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fashion.shop;


public class OrderController {
    
    public boolean addOrders(Orders order){
        OrderList orderList = DBConnection.getInstance().getOrderList();
        return  orderList.add(order);
    }
    public Orders[] getAllOrders(){
        OrderList orderList = DBConnection.getInstance().getOrderList();
        return orderList.toArray();
    }
    public Orders searchCustomer(String id){
        OrderList orderList = DBConnection.getInstance().getOrderList();
        return orderList.search(id);
    }
   

}
