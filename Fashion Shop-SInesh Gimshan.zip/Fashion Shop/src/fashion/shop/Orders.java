/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fashion.shop;

/**
 *
 * @author Sinesh Gimshan
 */
public class Orders{
	private String orderId;
	private String phoneNb;
	private String size;
	private int qty;
	private double amount;
	private int status =0;
	
	public Orders(String orderId,String phoneNb,String size,int qty,double amount){
		this.orderId=orderId;
		this.phoneNb=phoneNb;
		this.size=size;
		this.qty=qty;
		this.amount=amount;
	}
	
	public void setOrderId(String orderId){
		this.orderId=orderId;
	}
			
	public void setPhoneNb(String phoneNb){
		if(phoneNb.length()==10&&phoneNb.charAt(0)=='0'){
			this.phoneNb=phoneNb;
		}
	}	
	
	public void setsize(String size){
		if(size.equals("xs")||size.equals("s")||size.equals("m")||size.equals("l")||size.equals("xl")||size.equals("xxl")){
		 this.size=size;
		}
	}
	
	public void setqty(int qty){
		this.qty=qty;
	}
	
	public void setamount(double amount){
		this.amount=amount;
	}
	
	public void setstatus(int status){
		this.status=status;
	}
	
	public String getOrderId(){
		return orderId;
	}
	
        
	
	public String getPhoneNb(){
		return phoneNb;
	}
	
	public String getsize(){
		return size;
	}
	
	public int getqty(){
		return qty;
	}
	
	public double getamount(){
		return amount;
	}
		
	public String getstatus(){
		switch(status){
			case 0:return "PROCESSING";
			case 1:return "DELIVERING";
			case 2:return "DELIVERED";
			default: return null ;
			}
	}
	
	}


