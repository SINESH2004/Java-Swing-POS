package fashion.shop;

public class OrderListImplement implements OrderList {

    private Orders[] ordersArray;
    private int nextIndex;
    private int intSize;
    private double loadFact;

    OrderListImplement(int intSize, double loadFact) {
        this.intSize = intSize;
        this.loadFact = loadFact;
        ordersArray = new Orders[intSize];
        nextIndex = 0;
    }

    private boolean isEmpty() {
        return nextIndex == 0;
    }

    private boolean isFull() {
        return nextIndex >= ordersArray.length;
    }

    public int size() {
        return nextIndex;
    }

    public boolean isValidOrderId(String id){
	for (int i = 0; i < DBConnection.getInstance().getOrderList().size(); i++){
            if (DBConnection.getInstance().getOrderList().get(i).getOrderId().equalsIgnoreCase(id)){
		return true;
            }
	}
	return false;
    }

    public boolean isValidContactNum(String number){
	for (int i = 0; i < DBConnection.getInstance().getOrderList().size(); i++){
            if (DBConnection.getInstance().getOrderList().get(i).getPhoneNb().equalsIgnoreCase(number)){
		return true;
            }
	}
	return false;
    }
    
    public String toString() {
        String list = "{";
        for (int i = 0; i < nextIndex; i++) {
            list += ordersArray[i] + ", "; 
        }
        return isEmpty() ? "{empty}" : list + "\b\b}";
    }

    public boolean add(Orders order) {
        if (isFull()) {
            extendArray();
        }
        ordersArray[nextIndex++] = order;
        return true;
    }

    private void extendArray() {
        Orders[] tempOrderArray = new Orders[ordersArray.length + (int) (ordersArray.length * loadFact)];
        for (int i = 0; i < ordersArray.length; i++) {
            tempOrderArray[i] = ordersArray[i];
        }
        ordersArray = tempOrderArray;
    }

    public boolean add(int index, Orders order) {
        if (!isValidIndex(index)) {
            return false;
        }
        if (isFull()) {
            extendArray();
        }
        for (int i = nextIndex - 1; i >= index; i--) {
            ordersArray[i + 1] = ordersArray[i];
        }
        ordersArray[index] = order;
        nextIndex++;
        return true;
    }

    public boolean isValidIndex(int index) {
        return index >= 0 && index < nextIndex;
    }

    public Orders[] toArray() {
        Orders[] tempCustomerArray = new Orders[nextIndex];
        for (int i = 0; i < nextIndex; i++) {
            tempCustomerArray[i] = ordersArray[i];
        }
        return tempCustomerArray;

    }

    public boolean remove(int index) {
        if (isValidIndex(index)) {
            for (int i = index; i < nextIndex - 1; i++) {
                ordersArray[i] = ordersArray[i + 1];
            }
            nextIndex--;
            Orders[] tempOrdersArray = new Orders[nextIndex];
            for (int i = 0; i < nextIndex; i++) {
                tempOrdersArray[i] = ordersArray[i];
            }
            ordersArray = tempOrdersArray;
            return true;
        }
        return false;
    }

    public boolean remove(Orders order) {
        return remove(indexOf(order));
    }

    public Orders get(int index) {
		return index >= 0 && index < nextIndex ? ordersArray[index] : null;
    }

    public int indexOf(Orders order) {
        if (order != null) {
            for (int i = 0; i < nextIndex; i++) {
                if (ordersArray[i].getOrderId().equalsIgnoreCase(order.getOrderId())) {
                    return i;
                }
            }
        }
        return -1;
    }
    
   
    public Orders search(String id) {
        for (int i = 0; i < nextIndex; i++) {
            if (ordersArray[i].getOrderId().equalsIgnoreCase(id)) {
                return ordersArray[i];
            }
        }
        return null;
    }

    
    public boolean set(Orders order) {
        int index = indexOf(order);
        if(index!=-1){
            ordersArray[index]=order;
            return true;
        }
        return false;
    }

    public String generateId(){
        int number = 0;
		if (DBConnection.getInstance().getOrderList().size() == 0){
			return "ODR#00001";
		}else{
			String id = DBConnection.getInstance().getOrderList().get(DBConnection.getInstance().getOrderList().size()-1).getOrderId();		
			number = Integer.parseInt(id.split("[#]")[1]);
			number++;
		}
		
	return String.format("ODR#%05d",number);
    }
    
    public static int isValidOrderIndex(String key){
		int index=-1;
		for (int i = 0; i <DBConnection.getInstance().getOrderList().size(); i++){
			if (DBConnection.getInstance().getOrderList().equals(key)){
				index=i;
				break;
			}
		}
		return index;
    }
    public void amountSorting(String[] sizes,int[]Quantity,double[] amount){
        for (int i = 0; i < amount.length-1; i++) {
            for (int j = i+1; j < amount.length; j++) {
                if (amount[i]<amount[j]) {
                    double high=amount[j];
                    amount[j]=amount[i];
                    amount[i]=high;
                    
                    int qty=Quantity[j];
                    Quantity[j]=Quantity[i];
                    Quantity[i]=qty;
                    
                    String size=sizes[j];
                    sizes[j]=sizes[i];
                    sizes[i]=size;
                }
            }
        }
    }
    
    public void quantitySorting(String[] sizes,int[] Quantity,double[] amount){
        for (int i = 0; i < amount.length-1; i++) {
            for (int j = i+1; j < amount.length; j++) {
                if (Quantity[i]<Quantity[j]) {
                    double high=amount[j];
                    amount[j]=amount[i];
                    amount[i]=high;
                    
                    int qty=Quantity[j];
                    Quantity[j]=Quantity[i];
                    Quantity[i]=qty;
                    
                    String size=sizes[j];
                    sizes[j]=sizes[i];
                    sizes[i]=size;
                }
            }
        }
    }
    @Override
    public int FindIndex(String[] uniqueContacts, String currentContact) {
		for (int i = 0; i < uniqueContacts.length; i++) {
			if (uniqueContacts[i].equals(currentContact)) {
				return i;
			}
		}
		return -1;

    }
    public int[] extendArray1(int[] array){
	int[] temp = new int[array.length+1];
        System.arraycopy(array, 0, temp, 0, array.length);
            return temp;
    }
    
    public double[] extendArray2(double[] array){
	double[] temp = new double[array.length+1];
        System.arraycopy(array, 0, temp, 0, array.length);
        	return temp;
    }

    public String[] extendArray(String[] array){
	String[] temp = new String[array.length+1];
        System.arraycopy(array, 0, temp, 0, array.length);
		return temp;
    }
}
